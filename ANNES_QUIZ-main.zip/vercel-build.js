// Simple build script for Vercel
console.log('Starting Vercel build...');

// The actual build is handled by Vercel's build system
// This file just needs to exist for Vercel to detect the build process
console.log('Build configuration complete');
